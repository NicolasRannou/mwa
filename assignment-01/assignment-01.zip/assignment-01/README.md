### Step 1 - Completed

### Step 2 - Completed

### Step 3 - Completed

Mobile user experience:

- Not easy to enter notes on mobile (when click on the title field, the keyboard comes out and hides the message field)
- Check for JSON support and handle it with json2.js if not supported
We might actually not have to test it: http://caniuse.com/#search=JSON
- Check for localStorage support and handle it with cookies if not supported
We might actually not have to test it: http://caniuse.com/#search=localstorage
Only opera mini issues.
- Check for CSS features such as gradient
- Responsive layout

Mobile delivery:

- Load css style only on large displays
- Minify code

Markup:

- User input not tested
- Functions attached to window
- Diary stored as plain HTML (rather AS JSON array)

### Step 4 - Completed

Moving to the next level...
